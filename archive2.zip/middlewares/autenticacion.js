var jwt = require('jsonwebtoken');

var SEED = require('../config/config').SEED;
//const poolMysql = require('../data/mariadb_config');
var ApiKey = require('../models/administracion/api-key');
var Role = require('../models/administracion/role');
/*
exports.registraAcceso = function(req, res, next) {

    
    let ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    let host = req.headers['host'];
    let slug = req.params.id;

    registraVisita({ip:ip, host:host, slug:slug}).then(data=>{
        next();
    });

}

async function registraVisita(data){
    let fecha = new Date();
    if(poolMysql){
        let salida = await poolMysql.query('INSERT INTO visualizaciones( slug, ip, host, visited) values (?, ?, ?, ?) ON DUPLICATE KEY UPDATE updated=NOW(), times=(times+1);',
        [data.slug, data.ip, data.host, fecha ], (error, result) => {
            if (error) {
                return res.status(401).json({
                    ok: false,
                    mensaje: 'no se puede registrar acceos',
                    errors: err
                });
            }

        });
    }
    
}
*/
// ==========================================
//  Verificar token
// ==========================================
exports.verificaToken = function(req, res, next) {

    //var token = req.query.token;
    const token = req.get('authorization')?.split(' ')[1] || req.get('token') || '';
    //token = token.replace('Bearer ')



    jwt.verify(token, SEED, (err, decoded) => {
        if (err) {
            return res.status(401).json({
                ok: false,
                mensaje: 'Token incorrecto',
                errors: err
            });
        }

        req.usuario = decoded.usuario;
        req.partner = decoded.partner;
        next();
    });

}


exports.verificaApiKey = function(req, res, next) {

    const token = req.get('API-KEY') || '';
    var origin = req.get('origin');
    var host = req.get('host');

    var host = origin?origin:host;

    console.log('host  : ' + host + ' apikey  : ' + token);

    ApiKey.findOne({host:host, apikey: token}, (err, info) => {

        if (err) {
            return res.status(401).json({
                ok: false,
                mensaje: 'Token incorrecto',
                errors: err
            });
        }
        if(info){
            req.partner = info.partner;
            next();
        }else{
            return res.status(401).json({
                ok: false,
                mensaje: 'No existe este token asociado a este host',
                errors: err
            });
        }
        
    });

}

// ==========================================
//  Verificar ADMIN
// ==========================================
exports.verificaADMIN_ROLE = function(req, res, next) {


    var usuario = req.usuario;

    if (usuario.role === 'ADMIN_ROLE' || usuario.role === 'USER_ROOT') {
        next();
    } else {

        return res.status(401).json({
            ok: false,
            mensaje: 'Token incorrecto - No es administrador',
            errors: { message: 'No es administrador, no puede hacer eso' }
        });

    }


}


// ==========================================
//  Verificar ADMIN o Mismo Usuario
// ==========================================
exports.verificaADMIN_o_MismoUsuario = async function(req, res, next) {
    var usuario = req.usuario;
    var id = req.params.id;
    if (usuario.role === 'USER_ROOT') {

        next();
    } else{
        if (usuario.partner !== null && usuario.partner !== undefined && usuario.partner !== '') {
            var roles = await Role.find({partner: usuario.partner});
            if (roles !== null && roles !== undefined && roles.length > 0) {
                var coincide = false;
                for (let i = 0; i < roles.length; i++) {
                    if (usuario.role === roles[i].nombrePrivado) {
                        coincide = true;
                    }
                }
                if (coincide) {
                    console.log('Es admin o mismo user - coincide con un rol creado para el partner');
                    next();
                } else {
                    if (usuario.role === 'ADMIN_ROLE' || 
                        usuario._id === id || 
                        usuario.role === 'USER_ROOT' || 
                        usuario.role === 'USER_SALE_CONTRACT'  || 
                        usuario.role === 'USER_SALE' || 
                        usuario.role === 'USER_ROLE' || 
                        usuario.role === 'ROLE_USER' || 
                        usuario.role === 'ROLE_SALE_PROMOTOR' ||
                        usuario.role === 'ROLE_PROMOTOR' ||
                        usuario.role === 'COORDINADOR_ROLE' ||
                        usuario.role === 'ROLE_GERENCIA' 
                    ) {
                        console.log('Es admin o mismo user - no coincide con los roles creados para el partner');
                        next();
                    } else {
                
                        return res.status(401).json({
                            ok: false,
                            mensaje: 'Token incorrecto - No es administrador ni es el mismo usuario',
                            errors: { message: 'No es administrador, no puede hacer eso' }
                        });
                
                    }
                }
            } else {
                if (usuario.role === 'ADMIN_ROLE' || 
                        usuario._id === id || 
                        usuario.role === 'USER_ROOT' || 
                        usuario.role === 'USER_SALE_CONTRACT'  || 
                        usuario.role === 'USER_SALE' || 
                        usuario.role === 'USER_ROLE' || 
                        usuario.role === 'ROLE_USER' || 
                        usuario.role === 'ROLE_SALE_PROMOTOR' ||
                        usuario.role === 'ROLE_PROMOTOR' ||
                        usuario.role === 'COORDINADOR_ROLE' ||
                        usuario.role === 'ROLE_GERENCIA' 
                    ) {
                        console.log('Es admin o mismo user - no coincide con los roles creados para el partner');
                        next();
                    } else {
            
                    return res.status(401).json({
                        ok: false,
                        mensaje: 'Token incorrecto - No es administrador ni es el mismo usuario',
                        errors: { message: 'No es administrador, no puede hacer eso' }
                    });
            
                }
            }
        } else {
            
            if (usuario.role === 'ADMIN_ROLE' || 
                usuario._id === id || 
                usuario.role === 'USER_ROOT' || 
                usuario.role === 'USER_SALE_CONTRACT'  || 
                usuario.role === 'USER_SALE' || 
                usuario.role === 'USER_ROLE' || 
                usuario.role === 'ROLE_USER' || 
                usuario.role === 'ROLE_SALE_PROMOTOR' ||
                usuario.role === 'ROLE_PROMOTOR' ||
                usuario.role === 'COORDINADOR_ROLE' ||
                usuario.role === 'ROLE_GERENCIA' 
            ) {
                console.log('Es admin o mismo user - no coincide con los roles creados para el partner');
                next();
            } else {
                return res.status(401).json({
                    ok: false,
                    mensaje: 'Token incorrecto - No es administrador ni es el mismo usuario',
                    errors: { message: 'No es administrador, no puede hacer eso' }
                });
            }
        }
    }

}

