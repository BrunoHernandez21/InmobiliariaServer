var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

var Schema = mongoose.Schema;


var rolesValidos = {
    values: ['ADMIN_ROLE','USER_SALE','USER_ROOT','ROLE_USER', 'USER_SALE_CONTRACT',
             'ROLE_SALE_PROMOTOR','ROLE_PROMOTOR', 'ROLE_COACH', 'ROLE_GERENCIA'],
    message: '{VALUE} no es un rol permitido'
};


var usuarioSchema = new Schema({
    password: { type: String, required: [false, 'La contraseña es necesaria'] },
    img: { type: String, required: false },
    ciudad : { type: String, required: false },
    longitud: Number,
    latitud: Number,
    address_components: Schema.Types.Mixed,
    zonaHoraria: Number,
    nombre: { type: String, required: false },
    surname: { type: String, required: false },
    email: { type: String, unique: true, required: [false, 'El correo es necesario'] },
    role: { type: String, required: true },
    tel: { type: String, required: false },
    cel: { type: String, required: false },
    direccion : { type: String, required: false },
    rfc : { type: String, required: false },
    urlMaps : { type: String, required: false },
    fechaNacimiento : { type: Date, required: false },
    numeroCliente : { type: String, required: false },
    numeroVendedor: { type: String, required: false },
    telefonoReferenciaUno : { type: String, required: false },
    telefonoReferenciaDos :{ type: String, required: false },
    nombreReferenciaUno :{ type: String, required: false },
    nombreReferenciaDos : { type: String, required: false },
    observaciones : { type: String, required: false },
    sexo : { type: String, required: false },
    partner : {  type: Schema.Types.ObjectId, ref: 'Partner', required: false },
    owner : {  type: Schema.Types.ObjectId, ref: 'Usuario', required: false },
    ownerName: String,
    comisionVendedor: { type: Number, required: false },
    estatus: {type: Boolean,  default:1},
    created : { type: Date, required: false , default: Date.now },
    title: String,
    uidFirebase: String,
    urlClientify: String,
    clavePublicaConekta: String,
    clavePrivadaConekta: String
});

usuarioSchema.plugin(uniqueValidator, { message: '{PATH} debe de ser único' });

module.exports = mongoose.model('Usuario', usuarioSchema);
