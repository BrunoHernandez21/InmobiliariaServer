'use strict'


var mongoose = require('mongoose');
var app = require('./app');
var port = process.env.PORT || 3000;

mongoose.Promise = global.Promise;





mongoose.connect("mongodb://localhost:27017/tookan", {  useFindAndModify: false, useNewUrlParser: true, useCreateIndex: true  }, (err, res) => {

    if (err) throw err;

    console.log('Base de datos: \x1b[32m%s\x1b[0m', 'online');
    app.listen(port, () => {
        console.log('Express server puerto %s: \x1b[32m%s\x1b[0m', port,'online');
    });

});