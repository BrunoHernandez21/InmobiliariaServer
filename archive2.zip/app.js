// Requires
var express = require('express');
var bodyParser = require('body-parser');
//var hbs = require('hbs');

// Inicializar variables
var app = express();

// CORS
app.use(function(req, res, next) {
    res.header("x-token", "*");
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, Authorization, API-KEY, X-TOKEN, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "POST, GET, PUT, DELETE, OPTIONS");
    next();
});

    // Body Parser
    // parse application/x-www-form-urlencoded
    app.use(bodyParser.urlencoded({ extended: false }))
    app.use(bodyParser.json())

    // Importar rutas
    // LOGIN
    var auth = require ('./routes/auth/auth');

    // IMAGEN Y SUBIDA DE ARCHIVOS
    //var uploadRoutes = require('./routes/upload-imagen/upload');
    //var imagenesRoutes = require('./routes/upload-imagen/imagenes');


    /* RUTAS */
    // LOGIN

    app.use('/api/auth', auth);

    //app.use('/api/', compruebaAccesoRuta);

    // IMAGEN Y SUBIDA DE ARCHIVOS
    //app.use('/api/upload', uploadRoutes);
    //app.use('/api/img', imagenesRoutes);

  


module.exports = app;