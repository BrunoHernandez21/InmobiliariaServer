var express = require('express');
var app = express();
var mdAutenticacion = require('../../middlewares/autenticacion');
var AuthController = require ('../../controllers/auth/auth.controller');

app.post('/login', AuthController.login);
app.post('/renuevatoken', [mdAutenticacion.verificaToken], AuthController.renuevaToken);
app.get('/user', [mdAutenticacion.verificaToken], AuthController.getUserFromToken);
app.get('/verify-user', [mdAutenticacion.verificaToken], AuthController.verifyUser);

//TODO: Revisar y eliminar si no se usa
app.get('/renuevatoken', [mdAutenticacion.verificaToken], AuthController.renuevaToken);

app.post('/google', [mdAutenticacion.verificaToken], AuthController.signByGoogle);
app.post('/Contrato', [mdAutenticacion.verificaToken], AuthController.signByContrato);
app.post('/reset-password', AuthController.resetPassword);

module.exports = app;