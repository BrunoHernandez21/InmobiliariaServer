
module.exports.EXPIRES_IN = '2d';
module.exports.SESSION_EXPIRES_AT = '2d';


module.exports.configMail = {
    host: 'mail.inc4.uno',
    port: 465,
    secure: true, // true for 465, false for other ports
    auth: {
        user: 'cotizarenton@inc4.uno', // generated ethereal user
        pass: 'o+&]c*8%Rwd&' // generated ethereal password
    }
}