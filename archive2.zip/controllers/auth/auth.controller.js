var express = require('express');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
var Contrato = require('../../models/contrato-servicios/contrato');
var Menu = require('../../models/administracion/menu');
var PlanUsuarioTarjeta = require('../../models/tarjetas/planUsuarioTarjeta');
var Partner = require('../../models/administracion/partner');
var mongoose = require('mongoose');
// Load the MySQL pool connection
//const poolMysql = require('../../data/mariadb_config');
var MailController = require('../../controllers/mail/mail.controller');

var SEED = require('../../config/config').SEED;

//var app = express();
var Usuario = require('../../models/administracion/usuario');



var moment = require('moment');
var GoogleAuth = require('google-auth-library');
var auth = new GoogleAuth;

const GOOGLE_CLIENT_ID = require('../../config/config').GOOGLE_CLIENT_ID;
const GOOGLE_SECRET = require('../../config/config').GOOGLE_SECRET;
const SESSION_EXPIRES_AT = require('../../config/config').SESSION_EXPIRES_AT;

const payloadJwt = {
    expiresIn: SESSION_EXPIRES_AT
    //expiresIn: 14400
}

const FULL_MENU = [
        {
            "id" : "Dashboard",
            "title" : "Dashboard",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "Dashboard",
                    "title" : "Dashboard",
                    "type" : "item",
                    "icon" : "bar_chart",
                    "url" : "/pages"
                }
            ]
        },
        {
            "id" : "Administración",
            "title" : "Administración",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "Partners",
                    "title" : "Partners ",
                    "type" : "item",
                    "icon" : "business_center",
                    "url" : "/administracion/partner"
                },
                {
                    "id" : "Usuarios",
                    "title" : "Usuarios",
                    "type" : "item",
                    "icon" : "people",
                    "url" : "/administracion/usuarios"
                },
                {
                    "id" : "Empresas",
                    "title" : "Empresas",
                    "type" : "item",
                    "icon" : "category",
                    "url" : "/administracion/empresas"
                },
                {
                    "id" : "Grupos",
                    "title" : "Grupos",
                    "type" : "item",
                    "icon" : "category",
                    "url" : "/administracion/grupos"
                },
                {
                    "id" : "Categorias",
                    "title" : "Categorias",
                    "type" : "item",
                    "icon" : "category",
                    "url" : "/administracion/categoria"
                },
                {
                    "id" : "Roles",
                    "title" : "Roles",
                    "type" : "item",
                    "icon" : "category",
                    "url" : "/administracion/roles"
                },
                {
                    "id" : "Menus",
                    "title" : "Menus",
                    "type" : "item",
                    "icon" : "category",
                    "url" : "/administracion/menus"
                }
            ]
        },
        {
            "id" : "Contratos",
            "title" : "Contratos",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "Contrato",
                    "title" : "Contratos",
                    "type" : "item",
                    "icon" : "card_membership",
                    "url" : "/contrato"
                }
            ]
        },
        {
            "id" : "Constructora",
            "title" : "Constructora",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "Complejos",
                    "title" : "Fraccionamientos",
                    "type" : "item",
                    "icon" : "business",
                    "url" : "/contratos/complejos"
                },
                {
                    "id" : "Contratos",
                    "title" : "Contratos",
                    "type" : "item",
                    "icon" : "card_membership",
                    "url" : "/contratos"
                },
                {
                    "id" : "Egresos",
                    "title" : "Egresos",
                    "type" : "item",
                    "icon" : "assignment_returned",
                    "url" : "/contratos/egresos"
                },
                {
                    "id" : "Ingresos",
                    "title" : "Ingresos",
                    "type" : "item",
                    "icon" : "assignment_turned_in",
                    "url" : "/contratos/ingresos"
                },
                {
                    "id" : "Terrenos",
                    "title" : "Terrenos",
                    "type" : "item",
                    "icon" : "terrain",
                    "url" : "/contratos/terrenos"
                },
                {
                    "id" : "Departamentos",
                    "title" : "Departamentos",
                    "type" : "item",
                    "icon" : "hotel",
                    "url" : "/contratos/departamentos"
                },
                {
                    "id" : "Casas",
                    "title" : "Casas",
                    "type" : "item",
                    "icon" : "home",
                    "url" : "/contratos/casas"
                }
            ]
        },
        {
            "id" : "Terrenos",
            "title" : "Terrenos",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "ComplejosTerrenos",
                    "title" : "Fraccionamientos",
                    "type" : "item",
                    "icon" : "business",
                    "url" : "/terrenos/complejos"
                },
                {
                    "id" : "ContratosTerrenos",
                    "title" : "Contratos",
                    "type" : "item",
                    "icon" : "card_membership",
                    "url" : "/terrenos/contratos"
                },
                {
                    "id" : "EgresosTerrenos",
                    "title" : "Egresos",
                    "type" : "item",
                    "icon" : "assignment_returned",
                    "url" : "/terrenos/egresos"
                },
                {
                    "id" : "IngresosTerrenos",
                    "title" : "Ingresos",
                    "type" : "item",
                    "icon" : "assignment_turned_in",
                    "url" : "/terrenos/ingresos"
                },
                {
                    "id" : "TerrenosTerrenos",
                    "title" : "Terrenos",
                    "type" : "item",
                    "icon" : "terrain",
                    "url" : "/terrenos/terrenos"
                },
                {
                    "id" : "DepartamentosTerrenos",
                    "title" : "Departamentos",
                    "type" : "item",
                    "icon" : "hotel",
                    "url" : "/terrenos/departamentos"
                },
                {
                    "id" : "CasasTerrenos",
                    "title" : "Casas",
                    "type" : "item",
                    "icon" : "home",
                    "url" : "/terrenos/casas"
                }
            ]
        },
        {
            "id" : "Productos",
            "title" : "Productos",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "Productos",
                    "title" : "Productos",
                    "type" : "item",
                    "icon" : "shopping_basket",
                    "url" : "/productos"
                }
            ]
        },
        {
            "id" : "Tarjetas",
            "title" : "Tarjetas",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "Tarjetas",
                    "title" : "Tarjetas",
                    "type" : "item",
                    "icon" : "credit_card",
                    "url" : "/tarjetas"
                },
                {
                    "id" : "PlanesTarjetas",
                    "title" : "Planes - Tarjetas",
                    "type" : "item",
                    "icon" : "dvr",
                    "url" : "/tarjetas/planes"
                },
                {
                    "id" : "PlanesUsuariosTarjetas",
                    "title" : "Planes - Usuarios",
                    "type" : "item",
                    "icon" : "people",
                    "url" : "/tarjetas/planesUsuarios"
                },
                {
                    "id" : "Configuraciones",
                    "title" : "Configuraciones",
                    "type" : "item",
                    "icon" : "settings",
                    "url" : "/configuraciones"
                }
            ]
        },
        {
            "id" : "Productos",
            "title" : "Productos - Inversiones",
            "type" : "group",
            "icon" : "pages",
            "children" : [
                {
                    "id" : "Productos",
                    "title" : "Productos",
                    "type" : "item",
                    "icon" : "money",
                    "url" : "/inversiones/productos"
                },
                {
                    "id" : "Contratos-Inversion",
                    "title" : "Contratos - Inversion",
                    "type" : "item",
                    "icon" : "money",
                    "url" : "/inversiones/contratos"
                },
                {
                    "id" : "Leads-Inversion",
                    "title" : "Leads - Inversion",
                    "type" : "item",
                    "icon" : "money",
                    "url" : "/inversiones/leads"
                },
                {
                    "id" : "InteresVariable-Inversion",
                    "title" : "Interes Variable - Inversion",
                    "type" : "item",
                    "icon" : "money",
                    "url" : "/inversiones/interesVariable/interes"
                },
                {
                    "id" : "Comisión-Inversion",
                    "title" : "Comisión - Inversion",
                    "type" : "item",
                    "icon" : "money",
                    "url" : "/inversiones/comisiones"
                },
                {
                    "id" : "Comisión-Vendedores-Inversion",
                    "title" : "Comisiónes Vendedores - Inversion",
                    "type" : "item",
                    "icon" : "money",
                    "url" : "/inversiones/comisionesVendedores"
                },
                {
                    "id" : "EstadosDeCuenta-Inversion",
                    "title" : "Estados De Cuenta - Inversion",
                    "type" : "item",
                    "icon" : "money",
                    "url" : "/inversiones/estadosDeCuenta"
                }
            ]
        }
    ]
;

//var mdAutenticacion = require('../../middlewares/autenticacion');
const menu = require('../../models/administracion/menu');

var admin = require('firebase-admin');

function renuevaToken(req, res){
    //const token = req.get('authorization') || '';
    const token = req.body.accessToken || 'XXX';


    jwt.verify(token, SEED, (err, decoded) => {
        console.log(decoded);
        if (err) {
            return res.status(401).json({
                ok: false,
                mensaje: 'Token incorrecto',
                errors: err
            });
        }

        var tokenNew = jwt.sign({ usuario: decoded.usuario }, SEED, payloadJwt);

        res.status(200).json({
            authenticated: true,
            token: tokenNew
            //usuario: decoded.usuario,
            //partner: decoded.partner
        }) ;
    });

};




function getUserFromToken(req, res){
    res.status(200).json(req.usuario);


};

function verifyUser(req, res){

    const token = req.get('authorization')?.split(' ')[1] || '';


    jwt.verify(token, SEED, (err, decoded) => {
        console.log(decoded);
        if (err) {
            return res.status(401).json({
                ok: false,
                mensaje: 'Token incorrecto',
                errors: err
            });
        }

        var tokenNew = jwt.sign({ usuario: decoded.usuario }, SEED, payloadJwt);

        res.status(200).json({
            authenticated: true,
            token: tokenNew
            //usuario: decoded.usuario,
            //partner: decoded.partner
        }) ;
    });

};

// ==========================================
//  Autenticación De Google
// ==========================================
function signByGoogle(req, res){
    var token = req.body.token || 'XXX';


    var client = new auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_SECRET, '');

    client.verifyIdToken(
        token,
        GOOGLE_CLIENT_ID,
        // Or, if multiple clients access the backend:
        //[CLIENT_ID_1, CLIENT_ID_2, CLIENT_ID_3],
        function(e, login) {

            if (e) {
                return res.status(400).json({
                    ok: true,
                    mensaje: 'Token no válido',
                    errors: e
                });
            }


            var payload = login.getPayload();
            var userid = payload['sub'];
            // If request specified a G Suite domain:
            //var domain = payload['hd'];

            Usuario.findOne({ email: payload.email }, (err, usuario) => {

                if (err) {
                    return res.status(500).json({
                        ok: true,
                        mensaje: 'Error al buscar usuario - login',
                        errors: err
                    });
                }

                if (usuario) {



                    delete usuario.password;
                    var token = jwt.sign({ usuario: usuario }, SEED, payloadJwt);

                    res.status(200).json({
                        ok: true,
                        usuario: usuario,
                        token: token,
                        _id: usuario._id,
                        menu: obtenerMenu(usuario.role),
                    });

                    // Si el usuario no existe por correo
                } else {

                    var usuario = new Usuario();


                    usuario.nombre = payload.name;
                    usuario.email = payload.email;
                    usuario.nickname = payload.nickname;

                    usuario.password = ':)';
                    usuario.img = payload.picture;
                    usuario.avatar = payload.avatar;
                    usuario.google = true;

                    usuario.save((err, usuarioDB) => {

                        if (err) {
                            return res.status(500).json({
                                ok: true,
                                mensaje: 'Error al crear usuario - google',
                                errors: err
                            });
                        }


                        var token = jwt.sign({ usuario: usuarioDB }, SEED, payloadJwt); // 4 horas

                        res.status(200).json({
                            ok: true,
                            usuario: usuarioDB,
                            token: token,
                            _id: usuarioDB._id,
                            menu: obtenerMenu(usuarioDB.role)
                        });

                    });

                }


            });


        });




};
// ==========================================
//  Verifica Partner
// ==========================================
async function verificaPartner(host) {

    let partner = await Partner.findOne({ host: host })
        .select('_id nombre host relatedPartner')
        .populate({ path: 'relatedPartner',
            select: 'nombre host img theme background colorTheme' })
    ;

    if (!partner) {
        return {
            estatus: 'error',
            mensaje: 'No existe el partner',
            host: host
        };
    }
    partner = partner.relatedPartner?partner.relatedPartner:partner;

    return {
        partner
    };
}
// ==========================================
//  Autenticación normal
// ==========================================
function login(req, res){
    console.log('.............................................login........................................................');
    var body = req.body;
    let filterUser;
    let loginByFirebase = false;
    if (body.loginByFirebase !== null && body.loginByFirebase !== undefined) {
        console.log('Se realiza el login a traves de firebase');
        loginByFirebase = body.loginByFirebase;
    }
    if (body.fbt) {
        console.log('body.fbt:' + body.fbt);
        admin.auth().verifyIdToken(body.fbt)
            .then(function(decodedToken) {
                let uid = decodedToken.uid;
                console.log(uid);
                filterUser = { uid: uid }
                // ...
            }).catch(function(error) {
            console.log(error);
            // Handle error
        });
    } else {
        filterUser = { email: body.email }
    }
    var host = req.get('origin');
    var partnerId = '';

    verificaPartner(host).then((data) => {

        console.log('data');
        console.log(data);
        if (data.partner?.alternate) {
            partnerId = data.partner.alternate._id;

        }else if(data.partner){
            partnerId = data.partner._id;

        }


        /*if(body.partner !== null && body.partner !== undefined && body.partner !== ''){
            partnerId = body.partner;
        }*/





        Usuario.findOne(filterUser) // Usuario.findOne({ email: body.email, estatus: true})

            .select('email img password nombre surname role partner estatus')
            .populate({
                path: 'empresa',
                select: '_id orgEmpresa'
            })
            .exec(async(err, usuarioDB) => {
                console.log(usuarioDB);
                if (err) {
                    return res.status(500).json({
                        ok: false,
                        mensaje: 'Error al buscar usuario',
                        errors: err
                    });
                }



                if (!usuarioDB) {
                    return res.status(400).json({
                        ok: false,
                        mensaje: 'Credenciales incorrectas - email',
                        errors: err
                    });
                }
                console.log('Estatus----------------------------------------------------');
                console.log(usuarioDB.estatus);
                if (usuarioDB.estatus !== true) {
                    return res.status(400).json({
                        ok: false,
                        mensaje: 'Usuario Inactivo - Contacta a tu Administrador para que active tu cuenta',
                        errors: err
                    });
                }

                if (!bcrypt.compareSync(body.password, usuarioDB.password)) {
                    if (loginByFirebase) {
                        let user = usuarioDB;
                        user.password = bcrypt.hashSync(body.password, 10);
                        usuarioDB = await Usuario.findByIdAndUpdate(usuarioDB?._id, user, {new:true});

                    } else {
                        return res.status(400).json({
                            ok: false,
                            mensaje: 'Credenciales incorrectas - password',
                            errors: err
                        });
                    }
                }

                var id1 = partnerId ? mongoose.Types.ObjectId(partnerId) : mongoose.Types.ObjectId();
                var id2 = usuarioDB.partner ? mongoose.Types.ObjectId(usuarioDB.partner) : mongoose.Types.ObjectId();

                if (id1.equals(id2) || usuarioDB.role === 'USER_ROOT') {


                    usuarioDB.password = '';

                    let payload = {
                        usuario: usuarioDB,


                    };

                    //console.log(payload);

                    var token = jwt.sign(payload, SEED, payloadJwt);

                    obtenerMenu(usuarioDB.role, id1).then(async (data) => {
                        //console.log(data);

                        var planUsuario  = await PlanUsuarioTarjeta.find({usuario: usuarioDB._id});

                        if (planUsuario.length > 0) {
                            if (planUsuario[0].estado === 'PAGADO') {
                                var now = new Date();
                                if (planUsuario[0].fechaFin <= now) {
                                    var planUsuarioTarjeta = planUsuario[0];
                                    planUsuarioTarjeta.estado = 'FINALIZADO';
                                    await planUsuarioTarjeta.save();
                                }
                            }
                        }

                        res.status(200).json({
                            ok: true,
                            usuario: usuarioDB,
                            token: token,
                            _id: usuarioDB._id,
                            partner: partnerId,
                            menu: data
                        });
                    });

                } else {

                    return res.status(400).json({
                        ok: false,
                        mensaje: 'Partner incorrecto - Partner',
                        host: host,
                        errors: err
                    });
                }

            })
    });
};



function signByContrato(req, res){
    var body = req.body;
    console.log(body);
    Contrato.findOne({ numeroContrato: body.numeroContrato })
        //.populate({
        //path: 'empresa',
        //  select: '_id orgEmpresa'
        //})

        .exec((err, ContratoDB) => {
            if (err) {
                return res.status(500).json({
                    ok: false,
                    mensaje: 'Error al buscar Contrato',
                    errors: err
                });
            }

            if (!ContratoDB) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'Credenciales incorrectas - numero de Contrato',
                    errors: err
                });
            }

            if (!bcrypt.compareSync(body.password, ContratoDB.password)) {
                return res.status(400).json({
                    ok: false,
                    mensaje: 'Credenciales incorrectas - password',
                    errors: err
                });
            }

            // Crear un token!!!
            ContratoDB.password = ':)';


            var token = jwt.sign({ contrato: ContratoDB }, SEED, payloadJwt); // 4 horas


            res.status(200).json({
                ok: true,
                contrato: ContratoDB,
                token: token,
                //_id: usuarioDB._id,
                //menu: obtenerMenu(usuarioDB.role),
                payload: payload
            });
        })
};

function resetPassword(req, res){
    var body = req.body;


    Usuario.findOne({email: body.email})
        .select('email nombre')
        .exec((err, userBBD) => {
            if (err) {
                return res.status(500).json({
                    ok: false,
                    mensaje: 'Error al buscar usuario',
                    errors: err
                });
            }

            if(userBBD){
                let newPwd = Math.random().toString(36).substr(2, 8);
                console.log(newPwd);
                let pwdEncrypted  = bcrypt.hashSync(newPwd, 10);


                Usuario.findByIdAndUpdate(userBBD?._id, {password: pwdEncrypted}, {},
                    (err, nuser) => {
                        userBBD.password = newPwd;
                        MailController.enviarCorreoNuevoPassword
                        (userBBD).then(data =>{
                            res.status(201).json({
                                message: 'Se ha enviado un correo con tu nuevo password',

                                status: 'ok'
                            }/*, err => {
                                res.status(500).json({
                                    message: 'Ocurrió un error al enviar el correo',
                                    error: err,
                                    status: 'ok'
                                });
                            }*/);
                        });
                    });
            }else{


                res.status(400).json({
                    message: 'Se ha enviado un correo con tu nuevo password',
                    status: 'error'
                });
            }
        });
}

async function obtenerMenu(role, partner) {
    console.log('role: ' + role + ' partner:' + partner)
    let filter = {};

    filter['rol'] = role;
    if (role === 'USER_ROOT') {
        filter['partner'] = { $in: [null] };
    } else {
        filter['partner'] = partner;
    }
    console.log('filter: ' + JSON.stringify(filter));

    let menu = await Menu.findOne(filter);



    if (!menu) {

        let menuNew = new Menu();
        menuNew.nombre = 'Menu';
        menuNew.rol = role;
        menuNew.partner = partner;
        menuNew.menu = FULL_MENU;
        let menu = await menuNew.save();

        return menu;
    } else {
        return menu.menu;
    }

}


module.exports={
    login,
    signByGoogle,
    verifyUser,
    getUserFromToken,
    renuevaToken,
    signByContrato,
    resetPassword
};